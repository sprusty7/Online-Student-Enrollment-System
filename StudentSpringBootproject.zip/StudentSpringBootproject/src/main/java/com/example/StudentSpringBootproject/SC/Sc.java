package com.example.StudentSpringBootproject.SC;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "sc")
public class Sc 
{
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)	
	private Long classid;
	@Column(name = "classname")
	private String classname;
	@Column(name = "studentid")
	private Long studentid;
	
	
	
	
	
	
	
	public Sc(String classname, Long studentid) {
		super();
		
		this.classname = classname;
		this.studentid = studentid;
	}
	public Sc() {
		
	}
	public Long getClassid() {
		return classid;
	}
	public void setClassid(Long classid) {
		this.classid = classid;
	}
	public String getClassname() {
		return classname;
	}
	public void setClassname(String classname) {
		this.classname = classname;
	}
	public Long getStudentid() {
		return studentid;
	}
	public void setStudentid(Long studentid) {
		this.studentid = studentid;
	}
	

}
