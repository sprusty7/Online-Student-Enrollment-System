package com.example.StudentSpringBootproject.Payment;

import org.springframework.stereotype.Controller;


import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import org.springframework.web.bind.annotation.PostMapping;






@Controller
public class PaymentController 
{
	private PaymentService paymentService;

	public PaymentController(PaymentService paymentService) {
		super();
		this.paymentService = paymentService;
	}
	
	@GetMapping("/payments")
	public String listPayments(Model model) {
		model.addAttribute("payments", paymentService.getAllPayments());
		return "payments";
	}

	
	
	@GetMapping("/payments/new")
	public String createPaymentForm(Model model) {
		
		
		Payment payment = new Payment();
		model.addAttribute("payments", payment);
		return "create_payment";
		
	}
	@PostMapping("/payments")
	public String savePayment(@ModelAttribute("payment") Payment payment) {
		paymentService.savePayment(payment);
		return "paymentsuccessfull";
	}
//	@GetMapping("/payments/edit/{registrationid}")
//	public String editStudentForm(@PathVariable Long registrationid, Model model) {
//		model.addAttribute("student", studentService.getStudentById(registrationid));
//		return "approve";
//	}
//	
//	
//	@PostMapping("/payments/{registrationid}")
//	public String updateStudent(@PathVariable Long registrationid,
//			@ModelAttribute("student") Student student,
//			Model model) {
//		Student existingStudent = studentService.getStudentById(registrationid);
////		existingStudent.setRegistrationid(registrationid);
////		existingStudent.setFirstname(student.getFirstname());
////		existingStudent.setCourseid(student.getCourseid());
////		existingStudent.setLastname(student.getLastname());
////		existingStudent.setDob(student.getDob());
////		existingStudent.setMobilenumber(student.getMobilenumber());
////		existingStudent.setEmailid(student.getEmailid());
////		existingStudent.setCourseapplied(student.getCourseapplied());
////		existingStudent.setLastcoursestudied(student.getLastcoursestudied());
////		existingStudent.setDateofpass(student.getDateofpass());
////		existingStudent.setAveragemarks(student.getAveragemarks());
////		existingStudent.setStatus(student.getStatus());
//		existingStudent.setStatus("Approved");
//		
//		
//		studentService.updateStudent(existingStudent);
//		return "redirect:/students";	
//	}
//	
	
}
